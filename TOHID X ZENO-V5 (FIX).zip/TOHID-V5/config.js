//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      
//                                                     𝐓𝐎𝐇𝐈𝐃_𝐊𝐇𝐀𝐍 𝐕5                                                
//                                                                                                      
//                                                         Ｖ：5.0                                                       
//                                                                                                      
//                                                                                                        
//              ████████╗░█████╗░██╗░░██╗██╗██████╗░  ██╗░░██╗██╗░░██╗░█████╗░███╗░░██╗
//              ╚══██╔══╝██╔══██╗██║░░██║██║██╔══██╗  ██║░██╔╝██║░░██║██╔══██╗████╗░██║
//              ░░░██║░░░██║░░██║███████║██║██║░░██║  █████═╝░███████║███████║██╔██╗██║
//              ░░░██║░░░██║░░██║██╔══██║██║██║░░██║  ██╔═██╗░██╔══██║██╔══██║██║╚████║
//              ░░░██║░░░╚█████╔╝██║░░██║██║██████╔╝  ██║░╚██╗██║░░██║██║░░██║██║░╚███║
//              ░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝╚═╝╚═════╝░  ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝                
//                                                                                                                       
//                                                                                                      
//                                                                                                                   
//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//*
//  * @project_name : TOHID_KHAN-V5
//  * @author : TOHID TECH TEAMS
//  * @youtube : https://www.youtube.com/@Tohidkhan_6332
//  * @description : TOHID_KHAN-V1 ,A Multi-functional whatsapp user bot.
//*
//*
//base by Tohid Khan 
//re-upload? recode? copy code? give credit ya :)
//Instagram: Tohidkhan6332
//Telegram: t.me/Tohid_mewati
//GitHub: @Tohidkhan6332
//WhatsApp: +91 7849917350
//want more free bot scripts? subscribe to my youtube channel: https://youtube.com/@Tohidkhan_6332
//   * Created By Github: Tohid khan 
//   * Credit To TOHID TECH TEAM 
//   * © 2024 TOHID_KHAN-V5
// ⛥┌┤
// */

require("./database/module")

//GLOBAL PAYMENT
global.storename = "𝐓𝐨𝐡𝐢𝐝"
global.dana = "𝐓𝐨𝐡𝐢𝐝"
global.qris = "𝐓𝐨𝐡𝐢𝐝"

// Simbol



// GLOBAL SETTING
global.owner = "𝐓𝐨𝐡𝐢𝐝"
global.namaown = "𝐓𝐨𝐡𝐢𝐝_𝐊𝐡𝐚𝐧"
global.nomorbot = "917849917350"
global.namaCreator = "𝐓𝐨𝐡𝐢𝐝_𝐊𝐡𝐚𝐧"
global.autoJoin = false
global.antilink = false
global.versisc = '𝟓.𝟎.𝟎'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com'
global.eggsnya = '15'
global.location = '1'

//JANGAN DIHAPUS/DIGANTI NANTI ERORR
var _0x4bbb19=_0x5efe;(function(_0x3f5cd9,_0x5f1fe3){var _0x2fb2b9=_0x5efe,_0x5901b9=_0x3f5cd9();while(!![]){try{var _0x1b960d=parseInt(_0x2fb2b9(0x19d))/0x1+-parseInt(_0x2fb2b9(0x196))/0x2+-parseInt(_0x2fb2b9(0x197))/0x3*(parseInt(_0x2fb2b9(0x191))/0x4)+parseInt(_0x2fb2b9(0x19b))/0x5+parseInt(_0x2fb2b9(0x19f))/0x6+-parseInt(_0x2fb2b9(0x19a))/0x7+parseInt(_0x2fb2b9(0x192))/0x8*(parseInt(_0x2fb2b9(0x199))/0x9);if(_0x1b960d===_0x5f1fe3)break;else _0x5901b9['push'](_0x5901b9['shift']());}catch(_0x322662){_0x5901b9['push'](_0x5901b9['shift']());}}}(_0x46a9,0x63da5),global[_0x4bbb19(0x198)]='â™¨ï¸Ž',global[_0x4bbb19(0x19e)]=_0x4bbb19(0x19c),global['linkyt']=_0x4bbb19(0x193),global['url']=_0x4bbb19(0x194),global[_0x4bbb19(0x195)]='https://chat.whatsapp.com/FPQYQkbqzqw8XOGdDWoxwu');function _0x5efe(_0x1b5aa2,_0x49232a){var _0x46a973=_0x46a9();return _0x5efe=function(_0x5efe12,_0x3fa000){_0x5efe12=_0x5efe12-0x191;var _0x211020=_0x46a973[_0x5efe12];return _0x211020;},_0x5efe(_0x1b5aa2,_0x49232a);}function _0x46a9(){var _0x22848f=['12592035FxyTPP','4653215xsVIJq','2366135PdUCOt','𝐓𝐎𝐇𝐈𝐃-𝐕𝟓','519856CVrZef','namabot','554376QNtwaU','3090200RRupnu','8DkEfpk','https://youtube.com/@Tohidkhan_6332','https://github.com/tohidkhan6332','isLink','1276604AGsmZo','3IGKKLZ','simbol'];_0x46a9=function(){return _0x22848f;};return _0x46a9();}

//GLOBAL THUMB
global.codeInvite = ""
global.imageurl = 'https://telegra.ph/file/042cd0b6121a7923fd5d2.jpg'
global.packname = "𝐓𝐨𝐡𝐢𝐝"
global.author = "𝐓𝐨𝐡𝐢𝐝_𝐊𝐡𝐚𝐧"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})