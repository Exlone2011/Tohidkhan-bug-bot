require("./global")

const mess = {
   wait: "`ᴘʀᴏsᴇs ᴀɴᴊɢ`",
   success: "`ʙᴇʀʜᴀsɪʟ ᴄᴏᴋ`",
   on: "*`[ On Feature ]` - Sudah Aktif*", 
   off: "*`[ Off Feature ]` - Sudah Off*",
   query: {
       text: "`ᴛᴇᴋsɴʏᴀ ᴍᴀɴᴀ ᴀɴᴊɢ`",
       link: "`ʟɪɴᴋɴʏᴀ ᴍᴀɴᴀ ᴀɴᴊɢ`",
   },
   error: {
       fitur: "`ᴇʀᴏʀʀ ᴄᴏᴋ, ʙᴜʀᴜᴀɴ ᴄʜᴀᴛ ᴅʀᴀʏ ʙɪᴀʀ ᴅɪᴘᴇʀʙᴀɪᴋɪ`",
   },
   only: {
       group: "`ғɪᴛᴜʀ ᴛᴏʜɪᴅ ᴋʜᴀɴ ɢʀᴜᴘ`",
       private: "`ғɪᴛᴜʀ ᴛᴏʜɪᴅ ᴋʜᴀɴ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ`",
       owner: "`ʟᴜ sɪᴀᴘᴀ ᴋᴏɴᴛᴏʟ`",
       admin: "`ғɪᴛᴜʀ ᴛᴏʜɪᴅ ᴋʜᴀɴ ᴀᴅᴍɪɴ`",
       badmin: "`ᴊᴀᴅɪɪɴ ɢᴡ ᴀᴅᴍɪɴ ᴅʟᴜ ᴛᴏʟᴏʟ`",
       premium: "`ғɪᴛᴜʀ ᴛᴏʜɪᴅ ᴋʜᴀɴ ᴍᴜʀʙᴜɢ, ɪɴɢɪɴ ᴊᴏɪɴ ᴍᴜʀʙᴜɢ? ᴄʜᴀᴛ ᴏᴡɴᴇʀ ᴅᴇɴɢᴀɴ ᴋᴇᴛɪᴋ .ᴏᴡɴᴇʀ`",
   }
}

global.mess = mess

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})