//base by DGXeon
//re-upload? recode? copy code? give credit ya :)
//YouTube: @DGXeon
//Instagram: unicorn_xeon13
//Telegram: t.me/xeonbotinc
//GitHub: @DGXeon
//WhatsApp: +916909137213
//want more free bot scripts? 
//subscribe to my youtube channel: https://youtube.com/@DGXeon

const fs = require('fs');
const chalk = require('chalk');

//owmner v card
global.ytname = "YT: tohidkhan_6332" //ur yt chanel name
global.socialm = "YT: https://youtube.com/@tohidkhan_6332" //ur github or insta name
global.location = "India, haryana, mewat" //ur location

//new
global.botname = '𝐓𝐎𝐇𝐈𝐃-𝐊𝐇𝐀𝐍' //ur bot name
global.ownernumber = ['917849917350'] //ur owner number, dont add more than one
global.ownername = '𝕄𝕣   𝕋   𝕠   𝕙   𝕚   𝕕' //ur owner name
global.websitex = "https://github.com/Tohidkhan6332"
global.wagc = "https://chat.whatsapp.com/FPQYQkbqzqw8XOGdDWoxwu"
global.themeemoji = '🪀'
global.wm = "𝐓𝐎𝐇𝐈𝐃-𝐊𝐇𝐀𝐍 Inc."
global.botscript = 'https://github.com/Tohidkhan6332' //script link
global.packname = "𝕄𝕣   𝕋   𝕠   𝕙   𝕚   𝕕"
global.author = "𝕄𝕣   𝕋   𝕠   𝕙   𝕚   𝕕"
global.creator = "917849917350@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["917849917350"] // Premium User

//channel id
global.xchannel = {
	jid: '120363207624903731@newsletter'
	}

//bot sett
global.typemenu = 'v12' // menu type 'v1' => 'v12'
global.typereply = 'v4' // reply type 'v1' => 'v4'
global.autoblocknumber = '92' //set autoblock country code
global.antiforeignnumber = '91' //set anti foreign number country code

global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々','〆']
global.tempatDB = 'database.json'

global.limit = {
	free: 100,
	premium: 999,
	vip: 'VIP'
}

global.uang = {
	free: 10000,
	premium: 1000000,
	vip: 10000000
}

global.mess = {
	error: 'Error!',
	nsfw: 'Nsfw is disabled in this group, Please tell the admin to enable',
	done: 'Done'
}

global.bot = {
	limit: 0,
	uang: 0
}

global.game = {
	suit: {},
	menfes: {},
	tictactoe: {},
	kuismath: {},
	tebakbom: {},
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});