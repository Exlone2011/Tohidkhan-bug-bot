
#### MULTI DEVICE WHATSAPP BOT ULTRA | STILL MANY HIDDEN COMMANDS

<p align="center">  
  <a href="https://youtu.be/nE4v4KWBfAU">
    <img alt="ULTRA" src="https://i.ibb.co/5v4vrfR/20241021-033752.jpg">
    <h1 align="center">ULTRA-MD 3.O</h1>
  </a>
</p>
<p align="center">
<a href="https://github.com/GlobalTechInfo"><img title="Author" src="https://img.shields.io/badge/ULTRA-MD-black?style=for-the-badge&logo=telegram"></a>
<p/>
<p align="center">
<a href="https://github.com/GlobalTechInfo?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/GlobalTechInfo?label=Followers&style=social"></a>
<a href="https://github.com/GlobalTechInfo/ULTRA-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/GlobalTechInfo/ULTRA-MD?&style=social"></a>
<a href="https://github.com/GlobalTechInfo/ULTRA-MD/network/members"><img title="Fork" src="https://img.shields.io/github/forks/GlobalTechInfo/ULTRA-MD?style=social"></a>
<a href="https://github.com/GlobalTechInfo/ULTRA-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/GlobalTechInfo/ULTRA-MD?label=Watching&style=social"></a>
</p>
<p align="center">

  <a aria-label="Join our chats" href="https://t.me/GlobalBotInc" target="_blank">
    <img alt="telegram" src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=telegram&logoColor=white" />
  </a>
 <h2 align="center">  NOTE
</h2>

### Bot Is Able To Reply In 5 Different Languages So Use .language command First After Getting Connection And Choose Your Native Language If It Is There, If Your Native Language Is Not Present There Then Choose en For English.

----

 <p align="center"><img src="https://profile-counter.glitch.me/{ULTRA-MD}/count.svg" alt="GlobalTechInfo :: Visitor's Count" old_src="https://profile-counter.glitch.me/{GlobalTechInfo}/count.svg" /></p>

----

  <a href="https://github.com/GlobalTechInfo/ULTRA-MD/fork"><img title="GLOBAL-MD" src="https://img.shields.io/badge/FORK-ULTRA MD-h?color=blue&style=for-the-badge&logo=stackshare"></a>

----

<p align="center">

1. #### First Method

Fork Repo & Just Replace Your Number

globalbotNumber = '923051391007'

In config.js And It Will Directly Shows You A Pairing Code At The End Of Deployment, Pair And Enjoy.

----
<p align="center">

2. #### Second Method

Fork Repo , Then Pair From Following, You'll Get A File After Pairing

Upload Your Creds.json File Inside The session Folder/Directory Of Fork

Then Deploy And Enjoy

----

1. #### SETUP

Fork the repo
    <br>
<a href='https://github.com/GlobalTechInfo/ULTRA-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>



Get Creds.json (Server 1)
    
 <a href='https://necessary-margaretha-oletters-ba309cdc.koyeb.app/' target="_blank"><img alt='SERVER 1' src='https://img.shields.io/badge/Creds.json-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

----
Get Creds.json (Server 2)
    <br>
<a href='https://replit.com/@qasimali1st/ULTRA-PAIRING#main.sh' target="_blank"><img alt='SERVER 2' src='https://img.shields.io/badge/Creds.json-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


set the Env Vars.
    <br>


**Note:** You'll need to set these environment variables 

| Variable | Description 
|---|---| 
| REMOVEBG_KEY | API key for www.remove.bg | 
| PREFIX | put any one symbol here except @ and + , leave it Blank if you want to use multi prefix |
| MODE | mode public or private |
| autoRead | make it true if you want bot to read messages |
| statusview | make it true if you want bot to view status | 
| OWNERS | owner number e.g 923444844060 | 
| BOTNAME | Your Bot Name | 
| antidelete | bot will forward deleted messages if you make it true | 

2. #### DEPLOY TO Toystack

 If You don't have an account in Toystack. Create an account.
    <br>
<p align="center"><a href="https://toystack.ai"> <img src="https://img.shields.io/badge/Toystack%20Account-blue?style=for-the-badge&logo=Toystack" width="220" height="38.45"/></a></p>


 Now Deploy
   <br>
 <div align="center">
  <a href="https://toystack.ai">
    <img src="https://img.shields.io/badge/Deploy%20To%20ToyStack-blue?style=for-the-badge&logo=Toystack" width="220" height="38.45" alt="Deploy to Toystack ">
  </a>
</div>

----

3. #### DEPLOY TO HEROKU

 If You don't have an account in Heroku. Create a account.
    <br>
<p align="center"><a href="https://signup.heroku.com"> <img src="https://img.shields.io/badge/heroku%20Account-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

Now Deploy
   <br>
 <div align="center">
  <a href="https://heroku.com/deploy?template=https://github.com/GlobTechInfo/Bypass">
    <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku">
  </a>
</div>

----

3. #### DEPLOY IN PANEL

<br>
   <p align="center"><a href='https://bot-hosting.net/?aff=1097457675723341836' target="_blank"><img alt='Panel Link'
src='https://img.shields.io/badge/HOSTING%20PANEL-blue?style=for-the-badge&logo=Cloudflare&logoColor=white' width="220" height="38.45"/></a>

----

  5. #### TUTORIAL FOR PANEL
  
  <br>
   <p align="center"><a href="https://youtu.be/nE4v4KWBfAU"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/nE4v4KWBfAU" width="220" height="38.45"/><br>
  
----

4. #### DEPLOY TO KOYEB

if you don't have a koyeb account. Create an account.
   <br>
   <p align="center"><a href="https://app.koyeb.com/auth/signup"> <img src="https://img.shields.io/badge/Koyeb account-blue?style=for-the-badge&logo=koyeb" width="220" height="38.45"/></a></p>

 Now deploy
   <br>
<p align="center"><a href="https://app.koyeb.com/auth/signin"> <img src="https://img.shields.io/badge/Deploy%20To%20Koyeb-orange?style=for-the-badge&logo=koyeb" width="220" height="38.45"/></a></p>
  
----

5. #### DEPLOY TO RENDER

if you don't have a Render account. Create an account.
   <br>
   <p align="center"><a href="https://dashboard.render.com/register"> <img src="https://img.shields.io/badge/Render account-blue?style=for-the-badge&logo=render" width="220" height="38.45"/></a></p>

 Now deploy
   <br>
   <p align="center"><a href="https://dashboard.render.com"> <img src="https://img.shields.io/badge/Deploy%20To%20Render-maroon?style=for-the-badge&logo=render" width="220" height="38.45"/></a></p>

----

6. #### Deploy In Replit
   <br>
   <p align="center"><a href="https://repl.it/github/GlobalTechInfo/ULTRA-MD"> <img src="https://img.shields.io/badge/Deploy%20To%20Replit-orange?style=for-the-badge&logo=replit" width="220" height="38.45"/></a></p>

----

7. #### Deploy In Code Space
   <br>
   <p align="center"><a href="https://github.com/codespaces/new"> <img src="https://img.shields.io/badge/Deploy%20To%20CodeSpace-black?style=for-the-badge&logo=visualstudiocode" width="220" height="38.45"/></a></p>
  
  
 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

----

<p align="center">
  
 7. #### DEPLOY IN TERMUX/UBUNTU
 
```
apt update && apt upgrade -y
```
```
pkg install proot-distro
```
```
proot-distro install ubuntu
```
```
proot-distro login ubuntu
```
```
apt update && apt upgrade -y
```
```
apt install -y webp git ffmpeg curl imagemagick
```
```
apt -y remove nodejs
curl -fsSl https://deb.nodesource.com/setup_lts.x | bash - && apt -y install nodejs
```
```
apt-get install build-essential libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev
```
```
git clone https://github.com/<your gitHub Username>/ULTRA-MD
cd ULTRA-MD
```
```
npm install && npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

- Star ⭐ the repo if you like ULTRA-MD.

6. #### CREDITS 
<div><button id="boton" type="button">FG98F</button></div>
<a href="https://github.com/FG98F"><img src="https://github.com/FG98F.png" width="100" height="100" alt="adiwajshing"/></a>

<div><button id="boton" type="button">GURU322</button></div>
<a href="https://github.com/GURU322"><img src="https://github.com/GURU322.png" width="100" height="100" alt="adiwajshing"/></a>



## `Main Dev` 
<a href="https://github.com/GlobalTechInfo"><img src="https://github.com/GlobalTechInfo.png" width="250" height="250" alt="GlobalTechInfo"/></a>
  
`ULTRA-MD - By GlobalTechInfo`

<h2 align="center">  Reminder
</h2>
   
## 
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.


<h2 align="center">  NOTICE
</h2>
   
## 
- Not For Sale
- If A plugin's code is obfuscated , You don't have permission to edit it in any form 
- Don't Forget to Give Credits If you are using or Reuploading My Plugins/files
- Have A Good Day


  
<p align="center">
  
[![JOIN WHATSAPP CHANNEL](https://raw.githubusercontent.com/Neeraj-x0/Neeraj-x0/main/photos/suddidina-join-whatsapp.png)](https://whatsapp.com/channel/0029VagJIAr3bbVBCpEkAM07)

--------
