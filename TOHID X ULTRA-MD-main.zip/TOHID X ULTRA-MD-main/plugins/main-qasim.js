let handler = async m =>
  m.reply(
    `

≡ © Tohid Khan Groups

─────────────
▢ Join WhatsApp Channel For Updates
https://whatsapp.com/channel/0029VaGyP933bbVC7G0x0i2T

▢ Group 2
https://chat.whatsapp.com/FPQYQkbqzqw8XOGdDWoxwu

─────────────
≡ Disabled links? Chat Directly! 

▢ Group WhatsApp 
 https://chat.whatsapp.com/FPQYQkbqzqw8XOGdDWoxwu
─────────────
▢ *Owner instagram*
 https://instagram.com/Tohidkhan6332

▢ *YouTube*
• https://www.youtube.com/@Tohidkhan_6332


`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['groups', 'channels', 'telegram', 'sgp', 'grp']

export default handler
