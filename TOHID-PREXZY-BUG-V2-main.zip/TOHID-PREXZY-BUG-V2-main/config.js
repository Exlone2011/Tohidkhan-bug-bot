require("./all/module")

global.owner = "https://whatsapp.com/channel/0029VaGyP933bbVC7G0x0i2T" 
global.namabot = "𝐓𝐎𝐇𝐈𝐃-𝐊𝐇𝐀𝐍 𝐁𝐔𝐆 𝐕𝟐" //BOT NAME
global.namaCreator = "*TOHID TECH*" //CREATOR NAME
global.autoJoin = false //DON'T CHANGE  / JANGAN GANTI
global.antilink = false //DON'T CHANGE  / JANGAN GANTI
global.versisc = '1.0.0' //DON'T CHANGE 
global.sessionName = 'session'
global.codeInvite = ""
global.imageurl = 'https://telegra.ph/file/042cd0b6121a7923fd5d2.jpg' //GANTI PP MU MENGGUNAKAN LINK TELEGRA PH
global.isLink = 'https://whatsapp.com/channel/0029VaGyP933bbVC7G0x0i2T' 
global.thumb = fs.readFileSync("./thumb.png") ///DON'T CHANGE  
global.audionya = fs.readFileSync("./all/sound.mp3") //DON'T CHANGE  
global.packname = "𝐓𝐎𝐇𝐈𝐃-𝐊𝐇𝐀𝐍 𝐁𝐔𝐆 𝐕𝟐" 
global.author = "*KING TOHID👑*" 
global.jumlah = "5" ////DON'T CHANGE

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
