/*

# Base By Mr Tohid 
# Owner ? : Tohid khan
!- do not delete this credit

*/

global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['917849917350']
global.ownMain = '917849917350'
global.NamaOwner = 'Mr-Tohid' //
global.sessionName = 'session'
global.connect = true // 
global.namabot = 'TOHID-V8' //
global.author = 'Mr-Tohid' //
global.packname = 'TOHID-V8' //
global.url1 = 'https://whatsapp.com/channel/0029VaGyP933bbVC7G0x0i2T' //
global.url2 = 'https://github.com/Tohidkhn6332' //
global.linkgc = 'https://chat.whatsapp.com/FPQYQkbqzqw8XOGdDWoxwu'
global.delayjpm = 3500
//Panel
global.domain = 'https://guru.sellerpanell.me' // your domian
global.apikey = 'ptla_aRq7aFBbQowvPwLChvjNLX5uE0rYZ6dUdGbFIhqUwUg' // 
global.capikey = 'ptlc_mI4q2CFLyxYSG9lqtpWVJSkqtxbQvZyheemGqW56VUH' // 
global.eggsnya = '15' // 
global.location = '1' // 

global.mess = { // 
ingroup: 'This feature can only be used in groups.',
admin: 'This feature is specifically for group admins.',
notadmin: "The bot must be an admin first",
owner: 'You are not admin orr  Mr Tohid.',
premium: 'You are not a premium user.',
seller: 'This feature can only be used by resellers and owners.',
usingsetpp: `Setpp can only be used by the owner, do you think Im stupid?`,
wait: '*Waiting for processing*',
success: 'Success sent by Tohid V8',
bugrespon: `Processs.....`
}

global.nick = { // Custom Sesuka Lu
aaa: "�T�S҉ O҉ H҉ I҉ D҉  V҉ 8",
bbb: "⃰C҉ R҉ A҉ S҉ H҉ ̺",
ccc: "M҉ A҉ S҉ T҉ E҉ R҉ M҉ I҉ N҉ D҉ 🔥 �? ‌‌‌‌‌‌‌‌‌‌�?",
ddd: "K҉ I҉ N҉ G҉  T҉ O҉ H҉ I҉ D҉ 🌎",
eee: "A҉ L҉ L҉  H҉ A҉ I҉ L҉  T҉ O҉ H҉ I҉ D҉ ҉ 🔥🔥"
}

global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})