//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      
//                                                     𝐓𝐎𝐇𝐈𝐃_𝐊𝐇𝐀𝐍 𝐕𝟏                                                
//                                                                                                      
//                                                         Ｖ：4.0                                                       
//                                                                                                      
//                                                                                                        
//              ████████╗░█████╗░██╗░░██╗██╗██████╗░  ██╗░░██╗██╗░░██╗░█████╗░███╗░░██╗
//              ╚══██╔══╝██╔══██╗██║░░██║██║██╔══██╗  ██║░██╔╝██║░░██║██╔══██╗████╗░██║
//              ░░░██║░░░██║░░██║███████║██║██║░░██║  █████═╝░███████║███████║██╔██╗██║
//              ░░░██║░░░██║░░██║██╔══██║██║██║░░██║  ██╔═██╗░██╔══██║██╔══██║██║╚████║
//              ░░░██║░░░╚█████╔╝██║░░██║██║██████╔╝  ██║░╚██╗██║░░██║██║░░██║██║░╚███║
//              ░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝╚═╝╚═════╝░  ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝                
//                                                                                                                       
//                                                                                                      
//                                                                                                                   
//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//*
//  * @project_name : TOHID_KHAN-V1
//  * @author : TOHID TEAMS TECH
//  * @youtube : https://www.youtube.com/@Tohidkhan_6332
//  * @description : TOHID_KHAN-V1 ,A Multi-functional whatsapp user bot.
//*
//*
//base by Tohid Khan 
//re-upload? recode? copy code? give credit ya :)
//Instagram: Tohidkhan6332
//Telegram: t.me/Tohid_mewati
//GitHub: @Tohidkhan6332
//WhatsApp: +91 7849917350
//want more free bot scripts? subscribe to my youtube channel: https://youtube.com/@Tohidkhan_6332
//   * Created By Github: Tohid khan 
//   * Credit To TOHID TECH TEAM 
//   * © 2024 TOHID_KHAN-V1
// ⛥┌┤
// */

const fs = require('fs');
const chalk = require('chalk');

//owmner v card
global.ytname = "YT: @Tohidkhan_6332" //ur yt chanel name
global.socialm = "GitHub: Tohidkhan6332" //ur github or insta name
global.location = "India, Haryana, Mewat" //ur location

//new
global.botname = '𝐓𝐎𝐇𝐈𝐃_𝐊𝐇𝐀𝐍-𝐕𝟏' //ur bot name
global.ownernumber = ['917849917350'] //ur owner number, dont add more than one
global.ownername = 'ᴛᴏʜɪᴅ ᴋʜᴀɴ 👑' //ur owner name
global.websitex = "https://youtube.com/@Tohidkhan_6332"
global.wagc = "https://chat.whatsapp.com/FPQYQkbqzqw8XOGdDWoxwu"
global.themeemoji = '⛩'
global.wm = "Mr Tohid Inc..."
global.botscript = 'https://github.com/Tohidkhan6332' //script link
global.packname = "ᴛᴏʜɪᴅ ᴛᴇᴄʜ 👑"
global.author = "MΛDΣ BY ᴛᴏʜɪᴅ ᴋʜᴀɴ 👑"
global.creator = "917849917350@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["917849917350"] // Premium User

//bot sett
global.typemenu = 'v12' // menu type 'v1' => 'v12'
global.typereply = 'v4' // reply type 'v1' => 'v4'
global.autoblocknumber = '212' //set autoblock country code
global.antiforeignnumber = '91' //set anti foreign number country code
global.antidelete = false //set anti delete 


global.listv = ['🕷️','❄️','🥀','🍀','🍁','🫧','✨','🌹','🌟']
global.tempatDB = 'database.json'

//---------------------------------------------------------------------------------------//
//api variables 

global.api = "https://api.maher-zubair.xyz/" ;
global.id = "RnJlZV9rZXlAc2FsbWFu" ;

//---------------------------------------------------------------------------------------//



// Description: This file is used to store global variables.


global.limit = {
	free: 100,
	premium: 999,
	vip: 'VIP'
}

global.uang = {
	free: 10000,
	premium: 1000000,
	vip: 10000000
}

global.mess = {
	error: 'Error!',
	nsfw: 'Nsfw is disabled in this group, Please tell the admin to enable',
	done: 'Done'
}

global.bot = {
	limit: 0,
	uang: 0
}

global.game = {
	suit: {},
	menfes: {},
	tictactoe: {},
	kuismath: {},
	tebakbom: {},
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});
